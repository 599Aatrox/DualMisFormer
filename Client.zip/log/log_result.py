# log_utils.py
import os
import logging
from datetime import datetime


def create_logger(log_dir="./logs", log_name="train", level=logging.INFO):
    """
    创建一个 logger，同时输出到控制台和文件。

    Args:
        log_dir (str): 日志保存目录
        log_name (str): 日志文件名前缀（会自动加上时间戳）
        level: 日志级别，默认 INFO

    Returns:
        logger: 配置好的 logger 对象
    """
    # 创建日志目录
    os.makedirs(log_dir, exist_ok=True)

    # 生成带时间戳的日志文件名
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    log_file = os.path.join(log_dir, f"{log_name}_{timestamp}.log")

    # 创建 logger
    logger = logging.getLogger(log_name)
    logger.setLevel(level)

    # 避免重复添加 handler（防止多次调用 create_logger 时重复输出）
    if logger.hasHandlers():
        logger.handlers.clear()

    # 格式化器
    formatter = logging.Formatter(
        fmt="%(asctime)s | %(levelname)-8s | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S"
    )

    # 文件处理器
    file_handler = logging.FileHandler(log_file, encoding="utf-8")
    file_handler.setLevel(level)
    file_handler.setFormatter(formatter)

    # 添加处理器
    logger.addHandler(file_handler)

    logger.info(f"Logger initialized. Log file: {log_file}")
    return logger